<?php
	/* Template Name: Inner page cart template */
	get_header();
?>  
	<?php if (is_array(get_field('leader-image'))) { 
		echo '<!-- page leader --> ';
		$leader_image_url = esc_url(get_field('leader-image')['url']);
		$leader_image_alt = esc_attr(get_field('leader-image')['alt']);
	?>
	<!-- Page content start: Page header -->
	<section id="main-site-content" class="bc-hero has-lines bc-innerpage-hero">
		<picture class="bc-hero__media">
			<img src="<?php echo $leader_image_url ?>" alt="<?php echo $leader_image_alt ?>" />
		</picture>
		<article class="bc-hero__body bc-content-component" aria-label="Main page hero body">
			<div class="bc-hero__body__content bc-text-block">
				<h1 class="bc-hero__heading"><?php the_title() ?></h1>
				<?php if (get_field('leader-sub-header') && strcmp(get_field('leader-sub-header'), '') !== 0) { ?>
				<h2><?php echo get_field('leader-sub-header') ?></h2>
				<?php } ?>
			</div>
		</article>
		<div class="bc-media-overlay"></div>
		<div class="lines"></div>
	</section><!-- // .bc-hero -->
	<?php }//end if get_file('leader-image') ?>
	
  <section id="body-content" class="bc-container " aria-label="Find out about our stylish featured walls and Ceilings">
		
		<div class="bc-content-component--text bc-content-block bc-column">
			<div class="bc-text-block">
				<h2 class="bc-section-title"><?php echo 'Your cart' ?></h2>
				<p><strong>Manage your shopping cart items here</strong>.</p>
			</div><!-- // .bc-text-block -->	
		</div><!-- // .bc-content-component -->
	
		<div class="bc-content-component bc-shopping-cart">
			<div class="bc-shopping-cart__items bc-grid">
				<div class="bc-shopping-cart-preview__item bc-card">
					<div class="bc-card__media is-16x9"></div>
					<h3 class="bc-card__heading">Fireplace name</h3>
					<p>€900.00</p>
					<p class="bc-shopping-cart-item__remove"> 
						<svg class="svg-icon "> 
							<use xlink:href="<?php echo get_theme_file_uri('assets/media/svg/icons/bc-svgs.svg'); ?>#close-x"></use>
						</svg>
						<a class="bc-shopping-cart-preview__remove" href="#">Remove from cart</a> 
					</p>
				</div><!-- // .bc-shopping-cart-preview__item -->
				<div class="bc-shopping-cart-preview__item bc-card">
					<div class="bc-card__media is-16x9"></div>
					<h3 class="bc-card__heading">Fireplace name</h3>
					<p>€900.00</p>
					<p class="bc-shopping-cart-item__remove"> 
						<svg class="svg-icon "> 
							<use xlink:href="<?php echo get_theme_file_uri('assets/media/svg/icons/bc-svgs.svg'); ?>#close-x"></use>
						</svg>
						<a class="bc-shopping-cart-preview__remove" href="#">Remove from cart</a> 
					</p>
				</div><!-- // .bc-shopping-cart-preview__item -->
				<div class="bc-shopping-cart-preview__item bc-card">
					<div class="bc-card__media is-16x9"></div>
					<h3 class="bc-card__heading">Fireplace name</h3>
					<p>€900.00</p>
					<p class="bc-shopping-cart-item__remove"> 
						<svg class="svg-icon "> 
							<use xlink:href="<?php echo get_theme_file_uri('assets/media/svg/icons/bc-svgs.svg'); ?>#close-x"></use>
						</svg>
						<a class="bc-shopping-cart-preview__remove" href="#">Remove from cart</a> 
					</p>
				</div><!-- // .bc-shopping-cart-preview__item -->
			</div><!-- // .bc-shopping-cart__items -->
			<div class="bc-shopping-cart__checkout">
				<h3>Cart total</h3>
				<table>
					<tbody>
						<tr><td><strong>Sub-total</strong></td><td class="bc-shopping-cart-preview__totals__item-cost"><strong>€3,400</strong></td></tr>
						<tr><td>VAT</td><td class="bc-shopping-cart-preview__totals__item-cost">€340</td></tr>
						<tr class="bc-shopping-cart-preview__totals__total"><td>Total</td><td class="bc-shopping-cart-preview__totals__item-cost">€3,400</td></tr>
					</tbody>
				</table>
				<button><a href="#">Checkout </a></button>
			</div><!-- // .bc-shopping-cart__items -->
		</div><!-- // .bc-content-component--media cart items -->
	</section>
	<?php get_footer(); ?>